import XCTest

import TestsTests

var tests = [XCTestCaseEntry]()
tests += TestsTests.allTests()
XCTMain(tests)