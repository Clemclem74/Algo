import XCTest

import LibrairieTests

var tests = [XCTestCaseEntry]()
tests += LibrairieTests.allTests()
XCTMain(tests)