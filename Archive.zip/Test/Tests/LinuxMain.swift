import XCTest
@testable import TestTests

XCTMain([
    testCase(TestTests.allTests),
])
