import XCTest
@testable import ProtocolesTests

XCTMain([
    testCase(ProtocolesTests.allTests),
])
